const { test } = require('@playwright/test');
import { ReportUtils } from '../utils/ReportUtils.js';
import { FakerUtility } from '../utils/FakerUtility.js';
const utils = require('../utils/CommonUtilities.js');
const path = require('path');
const testData = utils.getTestdata('test-data/userData.xlsx', 'Sheet1');


const PROJECT_ROOT = process.cwd();
const REPORTS_ROOT = path.join(PROJECT_ROOT, 'reports');

const TODAYS_DATE = utils.getCurrentDate();
const REPORT_PATH = path.join(REPORTS_ROOT, TODAYS_DATE);





let globalReportPath = '';



test.beforeAll(async () => {
  await utils.createFolder(REPORT_PATH);
  console.log(`Reports folder ready at: ${REPORT_PATH}`);

  await ReportUtils.createExcelSheet(REPORT_PATH);
});
testData.forEach((data) => {


  test(`TC-${data.TestCase_ID}`, async ({ browser }) => {
    let globalReportPath = "";
    let policyNumber = ""
    const startTime = Date.now();
    let status = "PASS";
    let errorMessage = "";

    try {
      const context = await browser.newContext(); //New instance created
      const page = await context.newPage(); //New Method Created

      const caseName = `Case-${data.TestCase_ID}`;
      const artifacts = path.join('Artifacts', TODAYS_DATE);
      const caseDir = path.join(artifacts, caseName);
      const requestID = String(data.Request_id).trim();
      const productCode = String(data.ProductCode).trim();




      await page.goto(`landing?request_id=${requestID}&clientId=PhonePe&productCode=${productCode}`);

      await page.getByRole('textbox', { name: 'Mobile Number' }).fill(String(FakerUtility.getIndianMobile()));

      await page.getByRole('textbox', { name: 'Email' }).fill(FakerUtility.getEmail());


      await page.getByRole('textbox', { name: 'Enter Or Upload your PAN' }).fill(data.Pan);


      await page.getByRole('textbox', { name: 'Date of Birth (DD/MM/YYYY)' }).fill(data.Dob);


      await page.getByRole('textbox', { name: 'Enter Aadhaar Card Number/VID' }).pressSequentially(String(data.Aadhaar));
      await utils.takeScreenshot(page, caseName, 'KYC_Page');
      await page.getByRole('button', { name: 'Proceed' }).click();
      await page.getByRole('button', { name: 'I Agree' }).click();
      await page.getByRole('textbox').click();
      await page.getByRole('textbox').fill('987654');
      await page.getByRole('button', { name: 'Verify OTP' }).click();
      await page.getByRole('button', { name: 'Proceed' }).click();
      await utils.takeScreenshot(page, caseName, 'Kyc_details');
      await page.getByRole('button', { name: 'Proceed' }).click();
      await utils.takeScreenshot(page, caseName, 'Kyc_details');
      //quotation Page
      const frequency = String(data.Frequency).trim();
      const pt = String(data.Pt).trim();
      const ppt = String(data.Ppt).trim();
      const premium = String(data.Premium).trim();

      //Click Frequency
      await page.locator('div').filter({ hasText: /^FrequencyMonthly$/ }).nth(1).click();
      await page.getByRole('button', { name: frequency }).click();

      const sectionMap = {
        SSIP: { pptLabel: 'Investment Duration' },
        SPS: { pptLabel: 'Premium Payment Term (PPT)' }
      };

      const ptContainer = page.locator('text=Policy Term (PT)').locator('..');
      const pptContainer = page.locator(`text=${sectionMap[productCode].pptLabel}`).locator('..');

      await utils.clickWithScroll(ptContainer, pt);
      await utils.clickWithScroll(pptContainer, ppt);


      await page.getByTestId('datatest-money-input-premium amount--').click();
      await page.getByTestId('datatest-money-input-premium amount--').fill(String(premium));
      await utils.takeScreenshot(page, caseName, 'Quotedetails');
      await page.getByRole('button', { name: 'Customize' }).click();


      //BI download
      await utils.downloadFile(page,
        page.getByText('Download the benefit'),
        path.join(caseDir, 'Bi.pdf'));

      ;
      // CIS DOWNLOAD
      await utils.downloadFile(page,
        page.getByText('Customer Information Sheet'),
        path.join(caseDir, 'CIS.pdf'));


      await utils.takeScreenshot(page, caseName, 'quoteupdated');
      await page.getByRole('button', { name: 'Get Offer Now!' }).click();

      if (productCode === 'SSIP') {
        console.log("SSIP FLOW ");
        await page.getByRole('checkbox', { name: 'I hereby agree to all above' }).check();
        await utils.takeScreenshot(page, caseName, 'DOGH');
        await page.getByRole('button', { name: 'Proceed' }).click();
        await page.getByRole('button', { name: 'Yes, Standing Instruction is' }).click();
      } else if (productCode === 'SPS') {
        console.log("SPS Flow Detected");
        await page.getByRole('button', { name: 'Yes, Standing Instruction is' }).click();
      }
      //Payment Screen Starts
      await page.waitForURL('https://devintegrationapi.tataaia.com/payment/processPayment', { timeout: 120000 });
      await page.locator('iframe[name="HyperServices"]').contentFrame().locator('[id="70000036"]').click();


      await page.locator('iframe[name="HyperServices"]').contentFrame().getByRole('textbox', { name: 'Enter Card Number' }).click();
      await page.locator('iframe[name="HyperServices"]').contentFrame().getByRole('textbox', { name: 'Enter Card Number' }).fill('4000 0000 0000 0002');

      await page.locator('iframe[name="HyperServices"]').contentFrame().getByRole('textbox', { name: 'MM/YY' }).fill('12/29');
      await page.locator('iframe[name="HyperServices"]').contentFrame().getByRole('textbox', { name: 'CVV' }).fill('123');
      await utils.takeScreenshot(page, caseName, 'PAymentdetails');
      await page.locator('iframe[name="HyperServices"]').contentFrame().getByRole('button', { name: 'Proceed to Pay' }).click();
      await page.waitForURL('https://uat1.billdesk.com/u2/websimulator/threeds2/dummyAcs', { timeout: 120000 });

      await page.getByRole('button', { name: '✉ Test OTP |' }).waitFor({
        state: 'visible',
        timeout: 120000

      });
      await page.getByRole('button', { name: '✉ Test OTP |' }).click();
      await page.getByRole('button', { name: 'Verify' }).click();

      //Nominee page start
      await page.goto('https://sellonlineuat.tataaia.com/app/digital/nominee-details?success=CHARGED&orderId=VXH8w8PIkBUTDd7bff&mandateStatus=ACTIVE&mandateId=7f4oMuujFgr3sbgPnMd3Rb');
      await page.getByRole('textbox', { name: 'Nominee Name' }).click();
      await page.getByRole('textbox', { name: 'Nominee Name' }).fill(FakerUtility.getFullName());
      await page.getByRole('textbox', { name: 'Date of Birth (DD/MM/YYYY)' }).click();
      await page.getByRole('textbox', { name: 'Date of Birth (DD/MM/YYYY)' }).fill('09/09/1999');
      await page.getByRole('button', { name: 'Male', exact: true }).click();
      await page.getByRole('button').nth(4).click();
      await page.locator('div').filter({ hasText: /^Brother$/ }).click();
      await page.getByRole('button', { name: '100%' }).click();
      await utils.takeScreenshot(page, caseName, 'Nomineedetails');
      await page.getByRole('button', { name: 'Proceed' }).click();
      await page.getByRole('checkbox', { name: 'I agree to all Declaration &' }).check();
      await page.getByRole('button', { name: 'Submit' }).click();
      await page.getByRole('textbox', { name: 'Enter OTP' }).click();
      await page.getByRole('textbox', { name: 'Enter OTP' }).fill('987654');
      await page.getByRole('button', { name: 'Verify OTP' }).click();
      await page.waitForURL('https://sellonlineuat.tataaia.com/app/digital/review-success');
      await utils.takeScreenshot(page, caseName, 'FinalDetails');

      await page.waitForSelector('text=Your Policy Number');

      policyNumber = (
        await page.getByText('Your Policy Number')
          .locator('xpath=following-sibling::*')
          .first()
          .textContent()
      )?.trim();

      const filePath = 'test-Data/userData.xlsx';
      utils.writePolicyNumber(filePath, 'Sheet1', data.originalIndex, policyNumber);

    } catch (error) {
      status = "FAIL";
      errorMessage = error.message || String(error);
      throw error;
    } finally {
      const durationInMinutes = ((Date.now() - startTime) / 60000).toFixed(2);

      // Append to Excel after each test case


      await ReportUtils.appendTestResult(REPORT_PATH, {
        testCase: `TC-${data.TestCase_ID}`,
        product: data.ProductCode,
        status,
        duration: durationInMinutes,
        errorMessage,
        policyNumber
      });



    }

  });

});
