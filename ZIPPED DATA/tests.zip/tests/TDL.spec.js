import { test } from '@playwright/test';
import { ReportUtils } from '../utils/ReportUtils.js';
const utils = require('../utils/CommonUtilities.js');
import { FakerUtility } from '../utils/FakerUtility.js';
const path = require('path');

const PROJECT_ROOT = process.cwd();
const REPORTS_ROOT = path.join(PROJECT_ROOT, 'reports');

const TODAYS_DATE = utils.getCurrentDate();
const REPORT_PATH = path.join(REPORTS_ROOT, TODAYS_DATE);



test.beforeAll(async () => {
  await utils.createFolder(REPORT_PATH);
  console.log(`Reports folder ready at: ${REPORT_PATH}`);

  await ReportUtils.createExcelSheet(REPORT_PATH);
});
function formatIndianCurrency(value) {
  const num = Number(value);
  return '₹' + num.toLocaleString('en-IN');
}
const testData = utils.getTestdata('test-data/userDataTDL.xlsx', 'Sheet1');
testData.forEach((data) => {
  test(`  TDL -${data.TestCase_ID}`, async ({ browser }) => {
    let globalReportPath = "";
    let policyNumber = "";
    const startTime = Date.now();
    let status = "PASS";
    let errorMessage = "";
    try {
      const context = await browser.newContext(); //New instance created
      const page = await context.newPage(); //New Method Created
      const caseName = `Case-${data.TestCase_ID}`;
      const artifacts = path.join('Artifacts', TODAYS_DATE);
      const caseDir = path.join(artifacts, caseName);
      const requestID = String(data.Request_id).trim();
      const productCode = String(data.ProductCode).trim();
     
      await page.goto(`landing?offerId=${requestID}&clientId=TATAFISolution&productCode=${productCode}`);
      //KYC DETAILS PAGE
      await page.getByRole('textbox', { name: 'Enter Or Upload your PAN' }).fill(data.Pan);
      await page.getByRole('textbox', { name: 'Date of Birth (DD/MM/YYYY)' }).fill(data.Dob);
      await page.getByRole('textbox', { name: 'Enter Aadhaar Card Number/VID' }).pressSequentially(String(data.Aadhaar));
      await utils.takeScreenshot(page, caseName, 'KYC_Page');
      //KYC CONFORMATION 
      await page.getByRole('button', { name: 'Proceed' }).click();
      await page.getByRole('button', { name: 'I Agree' }).click();
      await page.getByRole('textbox').click();
      await page.getByRole('textbox').fill('987654');
      await page.getByRole('button', { name: 'Verify OTP' }).click();
      await page.getByRole('button', { name: 'Proceed' }).click();
      await page.getByRole('button', { name: 'Proceed' }).click();
      //Basic Details
      if (productCode === 'SRP' || productCode === 'MRSS' || productCode === 'SSRS') {
        await page.waitForURL('https://sellonlineuat.tataaia.com/app/digital/basic-details');
        await page.getByRole('textbox', { name: 'Height (cm)' }).fill('160');
        await page.getByRole('textbox', { name: 'Weight (kg)' }).fill('55');
        await page.getByRole('button', { name: 'Next' }).click();
        await page.getByRole('button', { name: 'Next' }).click();
        await page.getByRole('button', { name: 'No' }).click();
        await page.getByRole('button', { name: 'Fetch Offer' }).click();
      } else if (productCode === 'SPS' || productCode === 'SSIP' || productCode === 'ISIP') {
        await page.waitForLoadState('networkidle');
      }
      //quotation Page
      await page.waitForURL('https://sellonlineuat.tataaia.com/app/digital/product-quote?quoteUpdated=false')
      const frequency = String(data.Frequency).trim();
      const pt = String(data.Pt).trim();
      const ppt = String(data.Ppt).trim();
      const premium = String(data.Premium).trim();
      //Click Frequency
      await page.getByRole('img', { name: 'edit' }).first().click();
      await page.getByRole('button', { name: frequency }).click();
      const sectionMap = {
        SSIP: { pptLabel: 'Investment Duration' },
        SPS: { pptLabel: 'Premium Payment Term (PPT)' },
        SSRS: { pptLabel: 'Premium Payment Term (PPT)' },
        SRP: { pptLabel:'Premium Payment Term (PPT)'}
      };
      const ptContainer = page.locator('text=Policy Term (PT)').locator('..');
      const pptContainer = page.locator(`text=${sectionMap[productCode].pptLabel}`).locator('..');
      await utils.clickWithScroll(ptContainer, pt);
      await utils.clickWithScroll(pptContainer, ppt);
      const product = (productCode || '').trim().toUpperCase();
      const inputProducts = ['SSIP', 'SPS', 'ISIP', 'FGAS'];
      const dropdownProducts = ['SRP', 'SSRS', 'MRSS'];
      if (inputProducts.includes(product)) {
        //  INPUT FLOW ONLY
        const inputBox = page.locator('input[type="text"]').first();
        await inputBox.waitFor({ state: 'visible', timeout: 10000 });
        await inputBox.click();
        await inputBox.fill('');
        await inputBox.pressSequentially(String(premium), { delay: 50 });
      } else if (dropdownProducts.includes(product)) {
        //  DROPDOWN FLOW ONLY
        await page.getByRole('combobox').click();
        await page.waitForTimeout(1000);
        const formattedValue = formatIndianCurrency(premium);
        let option = page.getByRole('option', { name: formattedValue });
        if (!(await option.isVisible().catch(() => false))) {
          option = page.getByRole('option').filter({
            hasText: formattedValue.replace(/,/g, '')
          });
        }
        await option.first().click();
      } else {
        throw new Error("Unknown product type: " + product);
      }
      await utils.takeScreenshot(page, caseName, 'Quotedetails');
      await page.getByRole('button', { name: 'Customize' }).click();
      //BI download
      await utils.downloadFile(page,
        page.getByText('Download the benefit'),
        path.join(caseDir, 'Bi.pdf'));
      // CIS DOWNLOAD
      await utils.downloadFile(page,
        page.getByText('Customer Information Sheet'),
        path.join(caseDir, 'CIS.pdf'));
      await utils.takeScreenshot(page, caseName, 'quoteupdated');
      await page.getByRole('button', { name: 'Get Offer Now!' }).click();
      if (productCode === 'SSIP' || productCode === 'ISIP' || productCode === 'SRP' || productCode === 'MRSS' || productCode === 'SSRS') {
        console.log("SSIP FLOW ");
        await page.getByRole('checkbox', { name: 'I hereby agree to all above' }).check();
        await utils.takeScreenshot(page, caseName, 'DOGH');
        await page.getByRole('button', { name: 'Proceed' }).click();
      } else if (productCode === 'SPS') {
        console.log("SPS Flow Detected");
        await page.waitForLoadState('networkidle');
      }
      await page.goto('https://sellonlineuat.tataaia.com/app/digital/nominee-details');
      await page.getByRole('textbox', { name: 'Nominee Name' }).click();
      await page.getByRole('textbox', { name: 'Nominee Name' }).fill(FakerUtility.getFullName());
      await page.getByRole('textbox', { name: 'Date of Birth (DD/MM/YYYY)' }).click();
      await page.getByRole('textbox', { name: 'Date of Birth (DD/MM/YYYY)' }).fill('08/01/1998');
      await page.getByRole('button', { name: 'Male', exact: true }).click();
      await page.getByRole('button').nth(4).click();
      await page.locator('div').filter({ hasText: /^Brother$/ }).click();
      await page.getByRole('button', { name: '100%' }).click();
      await utils.takeScreenshot(page, caseName, 'Nominee_Details');
      await page.getByRole('button', { name: 'Proceed' }).click();
      await page.getByRole('checkbox', { name: 'I agree to all Declaration &' }).check();
      await page.getByRole('button', { name: 'Submit' }).click();
      await page.getByRole('textbox', { name: 'Enter OTP' }).click();
      await page.getByRole('textbox', { name: 'Enter OTP' }).fill('987654');
      await utils.takeScreenshot(page, caseName, 'OTP Validation');
      await page.getByRole('checkbox', { name: 'I understand that once I' }).check();
      await page.getByRole('button', { name: 'Verify OTP' }).click();


      // Wait after OTP verification
     
// ✅ Wait until policyNumber appears in URL (even briefly)
policyNumber = await page.waitForFunction(() => {
  const params = new URL(window.location.href).searchParams;
  return params.get('policyNumber');
}, {
  timeout: 30000
});

policyNumber = await policyNumber.jsonValue();

console.log('✅ Policy Number captured from URL:', policyNumber);
await utils.takeScreenshot(page, caseName, 'Policy_No');
// Safety validation
if (!policyNumber) {
  throw new Error('❌ Policy Number not found in URL');
}

// Save to Excel
await utils.writePolicyNumber(
  'test-data/userDataTDL.xlsx',
  'Sheet1',
  data.originalIndex,
  policyNumber
);

      
    } 
    catch (error) {
      status = "FAIL";
      errorMessage = error.message || String(error);
      throw error;  // ✅ MUST
    }
    finally {
      const durationInMinutes = ((Date.now() - startTime) / 60000).toFixed(2);
    
      
      await ReportUtils.appendTestResult(REPORT_PATH, {
        testCase: `TC-${data.TestCase_ID}`,
        product: data.ProductCode,
        status,
        duration: durationInMinutes,
        errorMessage,
        policyNumber
      });

    }
    
  });
});
